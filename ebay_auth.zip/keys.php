<?php 

$ebay_token_url = 'https://api.ebay.com/identity/v1/oauth2/token';
$ebay_client_id = 'AtsushiK-Etoren-PRD-e132041a0-f9c6b726';
$ebay_client_secret = 'PRD-132041a01524-2ea9-4998-93e1-89ef';
$ebay_redirect_uri = 'Atsushi_Kurihar-AtsushiK-Etoren-noiupgut';


?>